
<!-- footer  -->
<footer class="container-fluid mt-5 banr_ol pt-5">
    <div class="container">
        <div class="row mb-5 mt-3">
            <div class="col-md-3">
                <div class="foot_e">
                    <h5>WHO WE ARE</h5>

                    <p>
                        Proin akshay handge vel velit auctor aliquet. Aenean sollicitudin,
                         Proin akshay handge vel velit auctor aliquet. Aenean sollicitudin,
                          Proin akshay handge vel velit auctor aliquet. Aenean sollicitudin,
                    </p>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="foot_e">
                    <h5>FOR CANDIDATE</h5>
                    <ul>
                        <li><a href="" >Add a Resume</a></li>
                        <li><a href="" >Job Alert</a></li>
                        <li><a href="" >Bookmark</a></li>
                    </ul>
                    
                </div>
            </div>
            <div class="col-md-3">
                <div class="foot_e">
                    <h5>FOR EMPLOYEERS</h5>
                    <ul>
                        <li><a href="" >Browse Candidate</a></li>
                        <li><a href="" >Add Job</a></li>
                        <li><a href="" >Job Page</a></li>
                    </ul>
                    
                </div>
            </div>
            <div class="col-md-3">
                <div class="foot_e">
                    <h5>INFORMATION</h5>
                    <ul>
                        <li><a href="" >Home</a></li>
                        <li><a href="" >About Us </a></li>
                        <li><a href="" >Contact Us</a></li>
                        <li><a href="" > Terms & Conditions</a></li>
                    </ul>
                    
                </div>
            </div>
        </div>
        <hr style="border-color:white">

        <div class="p-2 text-center foot_e">
            <p class="m-0">© 2019-20 Job Pro. All Rights Reserved.</p>
        </div>
    </div>    
</footer>
</body>
</html>