<?php 
	include"header.php"
?>
<style>

.nav-pills .nav-link.active, .nav-pills .show>.nav-link {
    color: #000;
     background-color: transparent; 
    font-weight: bold;
    font-size: 17px;
}
</style>
<div class="container" style="margin-top: 130px">

  <div class="row">
    <div class="col-md-2 mt-5">
        <ul class="nav nav-pills flex-column border-right" id="myTab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Saved</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Applied</a>
  </li>
 <!--  <li class="nav-item">
    <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Contact</a>
  </li> -->
</ul>
    </div>
    <!-- /.col-md-4 -->
        <div class="col-md-10">
<div class="text-center">
	<h4>My Jobs</h4>
</div>

      <div class="tab-content" id="myTabContent">
  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
  <h5>My Saved Jobs</h5>
   <hr>
   <a href="job_details.php" class="border p-3 JJH_j">
		<div class="m-0 row">
			<div class="col-md-8">
				<h5 class="m-0 txt_X">Web Developer</h5>
				<span>SYNERGY WEB DESIGNERS</span><br>
				
				<ul class="d-flex m-0 ml-2 px-3">
					<li><small> 2 to 5 Yrs</small></li>
					<li class="ml-5"><small>Delhi</small></li>
				</ul>
			</div>
			<div class="col-md-4 text-right">
				<small>date</small>
			</div>
		</div>
		<div class="px-3"><small>Required Web Developer Key Skills required - Excellent Knowledge of PHP , Ajax , MySQL , MySQLI , Jquery , XML , HTML5 , CSS3</small>
		</div>
		<hr>
		<div class="row m-0">
			<div class="col-md-8">
				<small><strong>Skills : </strong>web designing, css, html, javascript, jquery</small>
			</div>
			<div class="col-md-4 text-right">
				<div class="btn btn-default border">Apply</div>
			</div>
		</div>
	</a>
	<a href="job_details.php" class="border p-3 JJH_j">
		<div class="m-0 row">
			<div class="col-md-8">
				<h5 class="m-0 txt_X">Web Developer</h5>
				<span>SYNERGY WEB DESIGNERS</span><br>
				
				<ul class="d-flex m-0 ml-2 px-3">
					<li><small> 2 to 5 Yrs</small></li>
					<li class="ml-5"><small>Delhi</small></li>
				</ul>
			</div>
			<div class="col-md-4 text-right">
				<small>date</small>
			</div>
		</div>
		<div class="px-3"><small>Required Web Developer Key Skills required - Excellent Knowledge of PHP , Ajax , MySQL , MySQLI , Jquery , XML , HTML5 , CSS3</small>
		</div>
		<hr>
		<div class="row m-0">
			<div class="col-md-8">
				<small><strong>Skills : </strong>web designing, css, html, javascript, jquery</small>
			</div>
			<div class="col-md-4 text-right">
				<div class="btn btn-default border">Apply</div>
			</div>
		</div>
	</a>
  </div>
  <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
  <h5>Applied Jobs</h5>
    <hr>
    <a href="job_details.php" class="border p-3 JJH_j">
		<div class="m-0 row">
			<div class="col-md-8">
				<h5 class="m-0 txt_X">Web Developer</h5>
				<span>SYNERGY WEB DESIGNERS</span><br>
				
				<ul class="d-flex m-0 ml-2 px-3">
					<li><small> 2 to 5 Yrs</small></li>
					<li class="ml-5"><small>Delhi</small></li>
				</ul>
			</div>
			<div class="col-md-4 text-right">
				<small>date</small>
			</div>
		</div>
		<div class="px-3"><small>Required Web Developer Key Skills required - Excellent Knowledge of PHP , Ajax , MySQL , MySQLI , Jquery , XML , HTML5 , CSS3</small>
		</div>
		<hr>
		<div class="row m-0">
			<div class="col-md-8">
				<small><strong>Skills : </strong>web designing, css, html, javascript, jquery</small>
			</div>
			<div class="col-md-4 text-right">
				<div class="btn btn-default border">Apply</div>
			</div>
		</div>
	</a>
	<a href="job_details.php" class="border p-3 JJH_j">
		<div class="m-0 row">
			<div class="col-md-8">
				<h5 class="m-0 txt_X">Web Developer</h5>
				<span>SYNERGY WEB DESIGNERS</span><br>
				
				<ul class="d-flex m-0 ml-2 px-3">
					<li><small> 2 to 5 Yrs</small></li>
					<li class="ml-5"><small>Delhi</small></li>
				</ul>
			</div>
			<div class="col-md-4 text-right">
				<small>date</small>
			</div>
		</div>
		<div class="px-3"><small>Required Web Developer Key Skills required - Excellent Knowledge of PHP , Ajax , MySQL , MySQLI , Jquery , XML , HTML5 , CSS3</small>
		</div>
		<hr>
		<div class="row m-0">
			<div class="col-md-8">
				<small><strong>Skills : </strong>web designing, css, html, javascript, jquery</small>
			</div>
			<div class="col-md-4 text-right">
				<div class="btn btn-default border">Apply</div>
			</div>
		</div>
	</a>
	<a href="job_details.php" class="border p-3 JJH_j">
		<div class="m-0 row">
			<div class="col-md-8">
				<h5 class="m-0 txt_X">Web Developer</h5>
				<span>SYNERGY WEB DESIGNERS</span><br>
				
				<ul class="d-flex m-0 ml-2 px-3">
					<li><small> 2 to 5 Yrs</small></li>
					<li class="ml-5"><small>Delhi</small></li>
				</ul>
			</div>
			<div class="col-md-4 text-right">
				<small>date</small>
			</div>
		</div>
		<div class="px-3"><small>Required Web Developer Key Skills required - Excellent Knowledge of PHP , Ajax , MySQL , MySQLI , Jquery , XML , HTML5 , CSS3</small>
		</div>
		<hr>
		<div class="row m-0">
			<div class="col-md-8">
				<small><strong>Skills : </strong>web designing, css, html, javascript, jquery</small>
			</div>
			<div class="col-md-4 text-right">
				<div class="btn btn-default border">Apply</div>
			</div>
		</div>
	</a>
  </div>

</div>
    </div>
    <!-- /.col-md-8 -->
  </div>
  
  
  
</div>
<!-- /.container -->





<!-- <?php 
	include"footer.php"
?> -->